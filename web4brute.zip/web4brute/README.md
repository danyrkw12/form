# web4brute
simple website for bruteforce target
Cyber Nevacad day 5 (Tools utilization)

tools req:
-hydra
-gobuster
